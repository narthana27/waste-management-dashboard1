// Initialize waste data
const wasteData = {
    plastic: 0,
    paper: 0,
    metal: 0,
    glass: 0,
  };
  
  // Add waste to the corresponding category
  function addWaste() {
    const wasteType = document.getElementById("waste-type").value;
    const quantity = parseFloat(document.getElementById("quantity").value);
  
    if (isNaN(quantity) || quantity <= 0) {
      alert("Please enter a valid quantity.");
      return;
    }
  
    // Update waste data
    wasteData[wasteType] += quantity;
  
    // Reset input field
    document.getElementById("quantity").value = "";
  
    // Update dashboard
    updateDashboard();
  }
  
  // Update the waste data and total display
  function updateDashboard() {
    const wasteDataDiv = document.getElementById("waste-data");
    wasteDataDiv.innerHTML = "";
  
    let totalWaste = 0;
    for (const type in wasteData) {
      totalWaste += wasteData[type];
      wasteDataDiv.innerHTML += `<div>${type.charAt(0).toUpperCase() + type.slice(1)}: ${wasteData[type]} kg</div>`;
    }
  
    document.getElementById("total").textContent = `Total Waste: ${totalWaste} kg`;
  }
  